#pragma once
#include <limits>
#include <iostream>
namespace Varparm{
	int ivaparm(int n, ...);
	int svarparm(short n, ...);
	double  fvarparm(float a, ...);
	double dvarparm(double a, ...);
}